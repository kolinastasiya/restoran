module com.example.chocolaterestoran {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.chocolaterestoran to javafx.fxml;
    exports com.example.chocolaterestoran;
}