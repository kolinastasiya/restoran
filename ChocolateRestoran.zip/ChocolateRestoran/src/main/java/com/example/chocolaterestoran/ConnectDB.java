package com.example.chocolaterestoran;

import java.sql.*;


//Класс для взаимодействия с БД
public class ConnectDB {

    Connection dbConnect;

    //IP адресс сервера
    private final String host = "127.0.0.1";

    //Порт
    private final String port ="3306";

    //Название схемы БД
    private  final String nameDB = "mydb";

    //Имя пользователя в БД
    private  final String userDB = "root";

    //Пароль пользователя от БД
    private  final String passDB = "123456";

    //Метод подключения к базе
    public Connection getDbConnection() throws ClassNotFoundException, SQLException{
        String connectionString = "jdbc:mysql://" + host + ":"
                + port + "/" + nameDB;
        Class.forName("com.mysql.cj.jdbc.Driver");

        dbConnect = DriverManager.getConnection(connectionString,
                userDB , passDB);
        return dbConnect;
    }

    //Метод Авторизации(проверка наличия логина и пароля в БД)
    public ResultSet getUser(String login, String password){
        ResultSet resSet = null;

        //Формирование запроса
        String select = "SELECT * FROM "+nameDB+".Employee WHERE login = ? and password = ?";

        try {
            PreparedStatement prSt = getDbConnection().prepareStatement(select);
            prSt.setString(1, login);
            prSt.setString(2, password);
            resSet = prSt.executeQuery();

        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return resSet;
    }

    public ResultSet getCategory(){
        ResultSet resSet = null;
        String select = "SELECT name FROM mydb.category";

        try {
            PreparedStatement prSt = getDbConnection().prepareStatement(select);

            resSet = prSt.executeQuery();

        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return resSet;
    }

    public ResultSet getProduct(){
        ResultSet resSet = null;
        String select = "SELECT name,price, discription, photo FROM " + nameDB + ".product"  ;
        try {
            PreparedStatement prSt = getDbConnection().prepareStatement(select);
            resSet = prSt.executeQuery();

        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return resSet;

    }






}
