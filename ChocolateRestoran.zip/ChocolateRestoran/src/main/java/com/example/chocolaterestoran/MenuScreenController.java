package com.example.chocolaterestoran;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MenuScreenController {
    ConnectDB dbHandler = new ConnectDB();

    @FXML
    private GridPane gridCat;

    @FXML
    private GridPane gridProduct;

    @FXML
    private ScrollPane scrollCat;

    private List<Category> categories = new ArrayList<>();
    private List<Product> products = new ArrayList<>();

    @FXML
    void initialize() throws SQLException {

        //Формирование продуктов
        products.addAll(getDataProduct());
        int row = 0;
        try {
            for (int i = 0; i < products.size(); i++) {
                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("itemProduct.fxml"));
                AnchorPane anchorPane = fxmlLoader.load();

                ItemProductController itemProductController = fxmlLoader.getController();
                itemProductController.setData(products.get(i));


                gridProduct.add(anchorPane, 0, row++); //(child, column, row)

                //set item drid width
                gridProduct.setMinWidth(Region.USE_COMPUTED_SIZE);
                gridProduct.setPrefWidth(Region.USE_COMPUTED_SIZE);
                gridProduct.setMaxWidth(Region.USE_PREF_SIZE);

                //set item drid height
                gridProduct.setMinHeight(Region.USE_COMPUTED_SIZE);
                gridProduct.setPrefHeight(Region.USE_COMPUTED_SIZE);
                gridProduct.setMaxHeight(Region.USE_PREF_SIZE);

                GridPane.setMargin(anchorPane, new Insets(5));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


        // Формирование категорий
        categories.addAll(getDataCategories());
        int column = 0;
        try {
            for (int i = 0; i < categories.size(); i++) {
                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("itemCategory.fxml"));
                AnchorPane anchorPane = fxmlLoader.load();

                ItemCategoryController itemCategoryController = fxmlLoader.getController();
                itemCategoryController.setData(categories.get(i));

                gridCat.add(anchorPane, column++, 0); //(child, column, row)

                //set item grid width
                gridCat.setMinWidth(Region.USE_COMPUTED_SIZE);
                gridCat.setPrefWidth(Region.USE_COMPUTED_SIZE);
                gridCat.setMaxWidth(Region.USE_PREF_SIZE);

                //set item grid height
                gridCat.setMinHeight(Region.USE_COMPUTED_SIZE);
                gridCat.setPrefHeight(Region.USE_COMPUTED_SIZE);
                gridCat.setMaxHeight(Region.USE_PREF_SIZE);

                GridPane.setMargin(anchorPane, new Insets(2));

            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public List<Category> getDataCategories() throws SQLException {
        List<Category> categors = new ArrayList<>();
        Category category;
        ResultSet result = dbHandler.getCategory();

        while (result.next()) {
            category = new Category();
            category.setName(result.getString(1));
            categors.add(category);
        }

        return categors;
    }

    public List<Product> getDataProduct() throws SQLException {
        List<Product> productos = new ArrayList<>();
        Product product;
        ResultSet result = dbHandler.getProduct();

        while (result.next()) {
            product = new Product();
            product.setName(result.getString(1));
            product.setPrice(result.getInt(2));
            product.setDiscription(result.getString(3));
            product.setPhoto(result.getString(4));
            productos.add(product);
        }
        return productos;
    }
}
